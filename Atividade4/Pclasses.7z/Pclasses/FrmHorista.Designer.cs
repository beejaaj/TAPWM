﻿namespace Pclasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.btnInstanciarNoParameters = new System.Windows.Forms.Button();
            this.btnInstanciarComParametros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(114, 196);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(132, 20);
            this.lblDataEntradaEmpresa.TabIndex = 19;
            this.lblDataEntradaEmpresa.Text = "Data de Ingresso";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(145, 152);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(101, 20);
            this.lblSalario.TabIndex = 18;
            this.lblSalario.Text = "Salario Bruto";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(195, 105);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 17;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(173, 62);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 16;
            this.lblMatricula.Text = "Matricula";
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(268, 190);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(184, 26);
            this.txtDataEntradaEmpresa.TabIndex = 15;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(268, 146);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(184, 26);
            this.txtSalario.TabIndex = 14;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(268, 105);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(362, 26);
            this.txtNome.TabIndex = 13;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(268, 56);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(133, 26);
            this.txtMatricula.TabIndex = 12;
            // 
            // btnInstanciarNoParameters
            // 
            this.btnInstanciarNoParameters.BackColor = System.Drawing.SystemColors.Window;
            this.btnInstanciarNoParameters.ForeColor = System.Drawing.SystemColors.WindowText;
            this.btnInstanciarNoParameters.Location = new System.Drawing.Point(75, 258);
            this.btnInstanciarNoParameters.Name = "btnInstanciarNoParameters";
            this.btnInstanciarNoParameters.Size = new System.Drawing.Size(283, 96);
            this.btnInstanciarNoParameters.TabIndex = 11;
            this.btnInstanciarNoParameters.Text = "Instanciar Horista sem parâmetros";
            this.btnInstanciarNoParameters.UseVisualStyleBackColor = false;
            // 
            // btnInstanciarComParametros
            // 
            this.btnInstanciarComParametros.BackColor = System.Drawing.SystemColors.Window;
            this.btnInstanciarComParametros.ForeColor = System.Drawing.SystemColors.WindowText;
            this.btnInstanciarComParametros.Location = new System.Drawing.Point(469, 258);
            this.btnInstanciarComParametros.Name = "btnInstanciarComParametros";
            this.btnInstanciarComParametros.Size = new System.Drawing.Size(283, 96);
            this.btnInstanciarComParametros.TabIndex = 10;
            this.btnInstanciarComParametros.Text = "Instanciar Horista passando parâmetros";
            this.btnInstanciarComParametros.UseVisualStyleBackColor = false;
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.btnInstanciarNoParameters);
            this.Controls.Add(this.btnInstanciarComParametros);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Button btnInstanciarNoParameters;
        private System.Windows.Forms.Button btnInstanciarComParametros;
    }
}