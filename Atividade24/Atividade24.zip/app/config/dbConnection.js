var sql = require('mssql');
var connSQLServer = function(){
    // https://teams.microsoft.com/l/message/48:notes/1729715859906?context=%7B%22contextType%22%3A%22chat%22%7D
    const sqlConfig = {
        user: 'BD2412027',
        password: 'A012458913a',
        database: 'BD', //BD, RA, Password
        server: 'apolo',
        options:{
            encrypt:false,
            trustServerCertificate: true
        }
        //Inserir professores no banco [ainda]
    }
    return sql.connect(sqlConfig);
}; module.exports = function(){ console.log('O autoload carregou o módulo de conexão'); return connSQLServer }