var texto = "servidor com express foi carregado por meio de módulo";
module.exports = texto;