﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal abstract class Empregado
    {
        // atributos
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public Empregado() { }

        public Empregado(int matricula, string nomeEmpregado, DateTime dataEntradaEmpresa)
        {
            Matricula = matricula;
            NomeEmpregado = nomeEmpregado;
            DataEntradaEmpresa = dataEntradaEmpresa;
        }

        // propriedades
        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }


        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }


        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        //métodos
        public virtual int TempoTrabalho()
        {
            // representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa.Date);
            return (span.Days);
        }

        //método abstrato que requer que a própria classe seja abstrata (não gera objetos)
        public abstract double SalarioBruto();
    }
}
