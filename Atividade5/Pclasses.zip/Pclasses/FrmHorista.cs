﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarNoParameters_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            MessageBox.Show("Nome = " + objHorista.NomeEmpregado + "\n" +
                "Matrícula = " + objHorista.Matricula + "\n" +
                "Dias trabalhados: " + objHorista.TempoTrabalho() +
                "\n" + "Salário: " +
                objHorista.SalarioBruto().ToString("N2"));

            MessageBox.Show($"Salário com aumento: {objHorista.SalarioBruto(50).ToString("N2")}");
        }

        private void btnInstanciarComParametros_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtDataEntradaEmpresa.Text),
                Convert.ToDouble(txtSalario.Text),
                Convert.ToDouble(txtHora.Text),
                Convert.ToInt32(txtFalta.Text));

            MessageBox.Show("Nome = " + objHorista.NomeEmpregado + "\n" +
                "Matrícula = " + objHorista.Matricula + "\n" +
                "Dias trabalhados: " + objHorista.TempoTrabalho() +
                "\n" + "Salário: " +
                objHorista.SalarioBruto().ToString("N2") /*+ "\n" +
                "Empresa: " + Mensalista.Empresa + "\n" +
                "Filial: " + Mensalista.Filial*/);
        }
    }
}
