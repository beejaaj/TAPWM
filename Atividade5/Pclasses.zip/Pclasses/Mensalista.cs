﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista : Empregado
    {
        //não podemos incluir restrições e outros códigos nesta forma de prop
        public double SalarioMensal { get; set; }

        public static String Empresa = "Tesla";
        public const String Filial = "Filial Brasil";

        public Mensalista() { }

        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
