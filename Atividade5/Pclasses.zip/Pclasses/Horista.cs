﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Horista : Empregado
    {
        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int DiasFalta { get; set; }

        public Horista() { }

        public Horista(int matx, string nomex, DateTime datax, double salarioHora, double numeroHora, int diasFalta)
        {
            this.Matricula = matx;
            this.NomeEmpregado = nomex;
            this.DataEntradaEmpresa = datax;
            this.SalarioHora = salarioHora;
            this.NumeroHora = numeroHora;
            this.DiasFalta = diasFalta;
        }

        public override double SalarioBruto()
        {
            return SalarioHora * NumeroHora;
        }
        public double SalarioBruto(double aumento)
        {
            double sal = SalarioHora * NumeroHora;
            return (sal + sal * (aumento / 100));
        }

        public override int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa.Date);
            return (Convert.ToInt32(span.Days) - DiasFalta);
        }
    }
}
