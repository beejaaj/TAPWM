﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciarNoParameters_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\n" +
                "Matrícula = " + objMensalista.Matricula + "\n" +
                "Dias trabalhados: " + objMensalista.TempoTrabalho() +
                "\n" + "Salário: " +
                objMensalista.SalarioBruto().ToString("N2"));
        }

        private void btnInstanciarComParametros_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtDataEntradaEmpresa.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\n" +
                "Matrícula = " + objMensalista.Matricula + "\n" +
                "Dias trabalhados: " + objMensalista.TempoTrabalho() +
                "\n" + "Salário: " +
                objMensalista.SalarioBruto().ToString("N2") + "\n" +
                "Empresa: " + Mensalista.Empresa + "\n" +
                "Filial: " + Mensalista.Filial);
        }
    }
}
