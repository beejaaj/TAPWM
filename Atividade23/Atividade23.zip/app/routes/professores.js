module.exports = function(app) {
    app.get('/informacao/professores', function(req,res){
        const sql = require('/mssql/msnodesqlv8');
        const sqlConfig = {
            user: 'LOGON',
            password: 'SENHA',
            database: 'site_fatec', //BD, RA, Password
            server: 'apolo',
            //Inserir professores no banco [ainda]
        }
        // https://teams.microsoft.com/l/message/19:Q2MS7lKSdz7QPEKsbO4ji51PXxlLmMhT5hb4YjnQHWc1@thread.tacv2/1729110176133?tenantId=cf72e2bd-7a2b-4783-bdeb-39d57b07f76f&groupId=c107f9f4-43d6-455c-ab42-fd3a29b87ead&parentMessageId=1729110176133&teamName=Tecnicas%20Avancadas%20de%20Programacao%20Web%20e%20Mobile-A962-T-ADS%20AMS-003-20240&channelName=General&createdTime=1729110176133
        async function getProfessores() {
            try {
                const pool = await sql.connect(sqlConfig);
            
                 const results = await pool.request().query('SELECT * from PROFESSORES')
            
                 res.render('informacao/professores',{profs:results.recordset})
      
             } catch (err) {
                 console.log(err)
            }
             //res.render('informacao/professores');
         }
        getProfessores();
        res.render('informacao/professores');\
    });
    }